A Pen created at CodePen.io. You can find this one at http://codepen.io/kyleHenwood/pen/Alayb.

 Professor X -> Wolverine.

A collection of svg + svg masking combined with HTML and CSS3 animations used to create a nifty button, I wrote a thing about why I had to mask and explained in more detail what's happening here: https://raygun.io/blog/2014/07/making-svg-html-burger-button/